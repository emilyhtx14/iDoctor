from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
#general steps
"""
create a function for making views
go to urls.py in the settings under testProject 
import the function from the views page
assign url path in urlpatterns 
"""

def home_view(request,*args, **kwargs):
    #return HttpResponse("<h1>Hello World</h1>")
    # print(request.user)
    #^basically prints into the console what user is currently on that page
    return render(request, "home.html", {})

# at this point go to testProject and wrap in URL's urls.py

def contact_view(request,*args, **kwargs):
    return HttpResponse("<h1>Contact")

def report_view(request, *args, **kwargs):
   return HttpResponse("<h1>Reports")

def about_view(request, *args, **kwargs):
    my_context = {
        "title": "This is about us",
        "my_number": 123,
        "my_list": [1,2,3,4,5],
        "my_html": "<h1>HelloWorld</h1>"
    }
    return render(request, "about.html", my_context)
