"""testProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path


'''
https://docs.djangoproject.com/en/3.1/ref/urls/#django.urls.path
path(route, view, kwargs=None, name=None)¶

The route argument should be a string or gettext_lazy() (see Translating URL patterns) that contains a URL pattern. 
The string may contain angle brackets (like <username> above) to capture part of the URL and send it as a keyword argument to the view. 
The angle brackets may include a converter specification (like the int part of <int:section>) which limits the characters matched and may also change the type of the variable passed to the view. 
For example, <int:section> matches a string of decimal digits and converts the value to an int. See How Django processes a request for more details.

The view argument is a view function or the result of as_view() for class-based views. It can also be an django.urls.include().

The kwargs argument allows you to pass additional arguments to the view function or method. See Passing extra options to view functions for an example.

See Naming URL patterns for why the name argument is useful.
'''
from pages.views import home_view, contact_view, report_view, about_view
from products.views import product_detail_view, product_create_view, dynamic_lookup_view
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home_view, name='home'),
    path('contact/', contact_view),
    path('report/', report_view),
    path('about/', about_view),
    path('product/', product_detail_view),
    path('create/', product_create_view),
    path('product/<int:my_id>/', dynamic_lookup_view, name = 'product'),
    path('', include('cal.urls'))
    # path('events/', event_detail_view),

]
