from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    # true is actually default
    symptoms = forms.CharField(initial = "",
                               label='',
                            widget=forms.Textarea(
                                attrs={
                                    "id" : 'symptoms-text-area',
                                    "rows": 5,
                                    "cols": 70,
                                    "style": 'font-size: 20px',
                                }))
    # gives the name of the form field
    severity = forms.CharField(initial = "",
                                  label='',
                                  widget=forms.Textarea(
                                      attrs={
                                            'id': 'severity-text-area',
                                            "rows": 5,
                                            "cols": 70,
                                            "style": 'font-size: 20px',
                                      }
                                  ))

    other = forms.CharField(initial= "",
                               label='',
                               widget=forms.Textarea(
                                   attrs={
                                       'id': 'other-text-area',
                                        "rows": 5,
                                        "cols": 70,
                                        "style": 'font-size: 20px',
                                   }
                               ))
    class Meta:
        model = Product
        fields = [
            'symptoms',
            'severity',
            'other'
        ]

class RawProductForm(forms.Form):
    # true is actually default
    symptoms = forms.CharField(required = True,
                            widget=forms.TextInput(
                                attrs= {
                                    "placeholder": "Your title"
                                }))
    # gives the name of the form field
    severity = forms.CharField(label='descr.',
                                  widget=forms.Textarea(
                                      attrs={
                                          "class": "new-class-name two",
                                          'id': 'my-id-for-text-area',
                                          "rows": 20
                                      }
                                  ))
    # gives an initial value to the form
    other = forms.CharField(initial= 'yes')