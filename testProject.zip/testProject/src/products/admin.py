from django.contrib import admin

# Register your models here.

from .models import Product
#importing product class from models.py relative b/c they're in the same directory/module

admin.site.register(Product)