from django.db import models

# Create your models here.
# product definition goes here, maps to a database

#models.Model inherits from the default Django class Model, allows all of the features to work
"""
class Product(models.Model):
    title = models.CharField(max_length = 120) # max length is required
    description = models.TextField(blank=True, null=True)
    price = models.DecimalField(decimal_places=2, max_digits=10000)
    #if you write blank = true as a parameter, then you're allowed to not fill out this field
    # if you write null = true or false in the database (actually not too important just look at the docs lol)
    summary = models.TextField(default = 'yay')
    # null = True,  would give all of
    # default=True
    features = models.BooleanField(default=True)
"""

class Product(models.Model):
    symptoms = models.CharField(max_length = 120) # max length is required
    severity = models.TextField(blank=True, null=True)
    #if you write blank = true as a parameter, then you're allowed to not fill out this field
    # if you write null = true or false in the database (actually not too important just look at the docs lol)
    other = models.TextField(default = 'yay')
    # null = True,  would give all of
    # default=True

"""
    if you run makemigrations and migrations without any parameters for features (and assuming you have existing
    data in the database, then you would have to provide a one-off default --> setting all old entries into the table 
    with a default value and all entries that will eventually be added don't have a default set
"""

# how to successfully add to the database via a python shell
"""
to run things from the python shell go to terminal
python manage.py shell
from products.models import Product
Product.objects.all()
Product.objects.create(title='chicken', description='fried',price=3,summary=spicy)

to get an object by id you can do 
Product.objects.get(id=1)
"""